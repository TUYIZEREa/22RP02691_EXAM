<?php
$conn=mysqli_connect("localhost","root","","nextech_portal_22RP02691");
session_start();


?>