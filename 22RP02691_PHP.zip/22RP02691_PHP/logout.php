<?php
require_once("connect.php");
?>
<?php
session_destroy();
header("location:login.php");


?>