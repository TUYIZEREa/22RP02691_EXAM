<?php
require_once("connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> LOGIN FORM</h1>
    <form method="post" action="">
        username<br><input type="text" name="username"value="<?php
        if(isset($_COOKIE['username'])){
            echo $_COOKIE['username'];
        }
        ?>" placeholder="Enter username"><br>
        Password<br><input type="password" name="password" value="<?php 
          if(isset($_COOKIE['password'])){
            echo $_COOKIE['password'];
        }
        ?>" placeholder="Enter password"><br>
        remember Me<input type="checkbox" name="checkbox" checked><br>
        <input type="submit" name="submit" value="Login">
</form>
<?php
if(isset($_POST['submit'])){

    $username=$_POST['username'];
    $pass=$_POST['password'];
    $select=mysqli_query($conn,"SELECT * FROM users where username='$username' AND password='$pass'");
    if(mysqli_num_rows($select)>0){
        $_SESSION['username']=$username;
        $_COOKIE['username']=$username;
        setcookie('username',$username,time()+60*60*7,'/');
        $_COOKIE['password']=$pass;
        setcookie('password',$pass,time()+60*60*7,'/');
        echo"<script> alert('username and password is correct');window.location='index.php';</script>";

    }
    else{

        echo"<script> alert(' incorrect username and password ');</script>";  
    }

}

?>
</body>
</html>