<?php
require_once("connect.php");
?>
<?php
$id=$_GET['id'];
$delete=mysqli_query($conn,"DELETE FROM employees where id='$id'");
if($delete){

    echo"<script> alert('arleady deleted!');window.location='report.php';</script>";
}


?>