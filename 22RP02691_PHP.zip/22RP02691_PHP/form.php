
<?php
require_once("connect.php");
?>
<?php
if(!isset($_SESSION['username'])){
    header("location:login.php");
}
?>
<?php
$name=$email=$phone=$position=$addr="";
$nameErr=$emailErr=$phoneErr=$positionErr=$addrErr="";
if(isset($_POST['submit'])){

    if(empty($_POST['employee_name'])){
        $nameErr="name is required";
    }else{


        $name=$_POST['employee_name'];
        if(!preg_match('/[a-zA-Z]+$/',$name)){
            $nameErr="use letters";
        }
    }
    if(empty($_POST['email'])){

        $emailErr="email is required";
    }else{
    
        $email=$_POST['email'];
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            $emailErr="wrong format of email";
    
    
    
        }
    }
    if(empty($_POST['phone'])){
        $phoneErr="phone is required";
    }else{


        $phone=$_POST['phone'];
        if(!preg_match('/[0-9]+$/',$phone)){
            $phone="use number 0 t0 9";
        }
    }
    if(empty($_POST['position'])){
        $positionErr="name is required";
    }else{


        $position=$_POST['position'];
        if(!preg_match('/[a-zA-Z]+$/',$name)){
            $positionErr="use letters";
        }
    }
    if(empty($_POST['address'])){
        $addrErr="address is required";
    }else{


        $name=$_POST['address'];
        if(!preg_match('/[a-zA-Z]+$/',$name)){
            $addrErr="use letters";
        }
    }

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <H1>Employee form </H1><br>
    <a href="report.php"> View records</a>
    <a href="logout.php"> logout</a>
    <form method="post" action="">
    Employee_name<input type="text" name="employee_name" placeholder="Enter name"><br>
    <?php echo $nameErr?><br>

        Email<input type="email" name="email" placeholder="Enter email"><br>
        <?php echo $emailErr?><br>
        phone<input type="text" name="phone" placeholder="+250"><br>
        <?php echo $phoneErr?><br>
        position<input type="text" name="position" placeholder="position"><br>
        <?php echo $positionErr?><br>
        address<input type="text" name="address" placeholder="Enter address"><br>
        <?php echo $addrErr?><br>
        <input type="submit" name="submit" value="save">
          <input type="reset" name="reset" value="Clear">
</form>
<?php
if(isset($_POST['submit'] )&& empty($nameErr)&& empty($emailErr)&& empty($phoneErr)&& empty($positionErr)&& empty($addrErr)     ){

    $name=$_POST['employee_name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $posit=$_POST['position'];
    $addr=$_POST['address'];
    $insert=mysqli_query($conn,"INSERT INTO employees(employee_name,email,phone,position,address)
    values('$name','$email','$phone','$posit','$addr')");
    if($insert){

        echo"<script> alert('employee recorded well');window.location='form.php';</script>";
    }
    else{
        echo"<script> alert('Not recorded');</script>";

    }
}


?>
    
</body>
</html>