<?php
require_once("connect.php");
?>
<?php
if(!isset($_SESSION['username'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>REPORT FORM</h1>
        <a href="form.php"> add employees</a>
        <a href="logout.php"> logout</a>
        
</body>
</html>

<?php
echo"<table border='1'><tr>
<th>id</th>
<th>employee name</th>
<th>email</th>
<th>phone</th>
<th>position</th>
<th>address</th>
<th>created at</th>
<th colspan='2'>Action</th>
</tr>
";
$select=mysqli_query($conn,"SELECT * FROM employees");
while($rows=mysqli_fetch_array($select)){
    echo"<tr>";
    echo"<td>".$rows['id']."</td>";
    echo"<td>".$rows['employee_name']."</td>";
    echo"<td>".$rows['email']."</td>";
    echo"<td>".$rows['phone']."</td>";
    echo"<td>".$rows['position']."</td>";
    echo"<td>".$rows['address']."</td>";
    echo"<td>".$rows['created_at']."</td>";
    echo"<td><a href='delete.php?id=".$rows['id']."'>Delete</a></td>";
    echo"<td><a href='update.php?id=".$rows['id']."'>Edit</a></td>";
    echo"</tr>";


}
echo"</table>";


?>