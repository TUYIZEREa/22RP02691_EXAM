<?php
require_once("connect.php");
?>
<?php
if(isset($_GET['id'])){
$id=$_GET['id'];
$select=mysqli_query($conn,"SELECT * FROM employees where id='$id'");
if(mysqli_num_rows($select)>0){

    $r=mysqli_fetch_array($select);





?>

<body>
    <H1>Update form</H1><br>
   
    <form method="post" action="">
    Employee_name<input type="text" name="employee_name"value="<?php echo $r['employee_name']?>"><br>
        Email<input type="email" name="email" value="<?php echo $r['email']?>"><br>
        phone<input type="text" name="phone" value="<?php echo $r['phone']?>"><br>
        position<input type="text" name="position" value="<?php echo $r['position']?>"><br>
        address<input type="text" name="address" value="<?php echo $r['address']?>"><br>
        <input type="submit" name="submit" value="Update">
          <input type="reset" name="reset" value="Clear">
</form>
<?php
}}

if(isset($_POST['submit'])){

    $name=$_POST['employee_name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $posit=$_POST['position'];
    $addr=$_POST['address'];
    $update=mysqli_query($conn,"UPDATE employees SET employee_name='$name',email='$email',phone='$phone',
    position='$posit',address='$addr' where id='$id'");
    if($update){

        echo"<script> alert('updateed well');window.location='report.php';</script>";
    }
    else{
        echo"<script> alert('NOT updateed');</script>";   
    }

}

?>