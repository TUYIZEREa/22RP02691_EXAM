
<?php
require_once("connect.php");
?>
<?php
if(!isset($_SESSION['username'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>user<?php echo "  ".$_SESSION['username']?>
    <H1>WELCOME nextech Innovation LTD</H1>
    <BR>
    <a href="form.php"> add employees</a>
    <a href="report.php"> View employees</a>
        <a href="logout.php"> logout</a>
        
</body>
</html>